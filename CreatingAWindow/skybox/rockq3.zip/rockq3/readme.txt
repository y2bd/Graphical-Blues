The Rock
An environment map by [WTF?]Mr-Gibs

    * Updated 2004-12-29
    * Check out other great artwork by [WTF?]Mr-Gibs
    * Send email to [WTF?]Mr-Gibs: mr-gibs@columbus.rr.com
    * Visit [WTF?]Mr-Gibs's homepage
    * Check out other great environment maps with the same theme: Cities & ruins

Originally created for the Q3F mod, which will soon morph into the terrific ETF mod. The environment map is very dark to fit the lighting in the level.

This environment map is in the public domain, and can be used freely in this format in non-commercial projects. For commercial projects or conversions to another format, please contact the artist.